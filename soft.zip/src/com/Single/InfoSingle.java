package com.Single;

public class InfoSingle {                        //���Ϣ��
	public int id; // �ID
	public String username; //�����û�
	public int infoType; // �����
	public String infoTitle; // �����
	public String infoContent; // �����
	public String infoLinkman; // ������
	public String infoPhone; // ��ϵ�绰
	public String infoEmail; // E-mail��ַ
	public String infoDate1; // ��Ϣ����ʱ��
	public String infoDate2; // �ʱ��
	public String infoState; // ��Ϣ���״̬
	public String infoPeopleNum; // ���������
	public String infoPeopleFreeNum; // �����ʣ������
	
	public int getId() {
		return id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getInfoType() {
		return infoType;
	}
	public void setInfoType(int infoType) {
		this.infoType = infoType;
	}
	public String getInfoTitle() {
		return infoTitle;
	}
	public void setInfoTitle(String infoTitle) {
		this.infoTitle = infoTitle;
	}
	public String getInfoContent() {
		return infoContent;
	}
	public void setInfoContent(String infoContent) {
		this.infoContent = infoContent;
	}
	public String getInfoLinkman() {
		return infoLinkman;
	}
	public void setInfoLinkman(String infoLinkman) {
		this.infoLinkman = infoLinkman;
	}
	public String getInfoPhone() {
		return infoPhone;
	}
	public void setInfoPhone(String infoPhone) {
		this.infoPhone = infoPhone;
	}
	public String getInfoEmail() {
		return infoEmail;
	}
	public void setInfoEmail(String infoEmail) {
		this.infoEmail = infoEmail;
	}
	public String getInfoDate1() {
		return infoDate1;
	}
	public void setInfoDate1(String infoDate1) {
		this.infoDate1 = infoDate1;
	}
	public String getInfoDate2() {
		return infoDate2;
	}
	public void setInfoDate2(String infoDate2) {
		this.infoDate2 = infoDate2;
	}
	public String getInfoState() {
		return infoState;
	}
	public void setInfoState(String infoState) {
		this.infoState = infoState;
	}
	public String getInfoPeopleNum() {
		return infoPeopleNum;
	}
	public void setInfoPeopleNum(String infoPeopleNum) {
		this.infoPeopleNum = infoPeopleNum;
	}
	public String getInfoPeopleFreeNum() {
		return infoPeopleFreeNum;
	}
	public void setInfoPeopleFreeNum(String infoPeopleFreeNum) {
		this.infoPeopleFreeNum = infoPeopleFreeNum;
	}

	
	
}